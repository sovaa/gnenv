from gnenv.environ import create_env

env = create_env()
